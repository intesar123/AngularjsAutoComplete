﻿// toggle class scroll 
$(window).scroll(function () {
    if ($(this).scrollTop() > 50) {
        $('.navbar-trans').addClass('afterscroll');
    } else {
        $('.navbar-trans').removeClass('afterscroll');
    }

});